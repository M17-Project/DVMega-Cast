#! /bin/bash
sudo pistar-watchdog.service stop
sudo dstarrepeater.service stop
sudo pistar-watchdog.timer stop
sudo dstarrepeater.timer stop
sudo mmdvmhost.timer stop
sudo mmdvmhost.service stop
sudo systemctl stop castserial.service

sudo mount -o remount,rw /

# firmware received in zip-format, unzip and continue
UPLOADED=./cast/*.zip
for zipped in $UPLOADED
do
       sudo unzip -o ${zipped} -d ./cast
done


FIRMWARE=./cast/*.hex
for found in $FIRMWARE
do
  echo "Found $found firmware..."
  # take action on this file, upload it to mainboard.

  sudo gpio mode 10 out
  sudo gpio write 10 1
  sudo gpio write 10 0
  sleep 1
  sudo gpio write 10 1
  sudo stm32flash -e 123 -v -w ${found} /dev/ttyAMA0
  sudo gpio mode 10 in

  # Make a backup of the uploaded FW to backup-folder, and reboot afterwards.
  sudo mv ${found} cast/backup
  sudo mv ./cast/*.zip ./cast/backup
  sudo cast-reset

sudo pistar-watchdog.service start
sudo dstarrepeater.service start
sudo pistar-watchdog.timer start
sudo dstarrepeater.timer start
sudo mmdvmhost.timer start
sudo mmdvmhost.service start
sudo systemctl start castserial.service



  #sudo reboot
done
